<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class buah extends Model
{
    use HasFactory;
    protected $table = "buah";
    protected $fillable = ["nama"];
}
