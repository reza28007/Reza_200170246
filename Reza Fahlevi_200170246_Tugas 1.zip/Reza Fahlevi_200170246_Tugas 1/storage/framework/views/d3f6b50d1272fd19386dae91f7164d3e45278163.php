
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        .container {
            padding: 20px;
            border: 1px solid #ccc;
            max-width: 400px;
            margin: 0 auto;
        }

        .form-group {
            margin-bottom: 10px;
        }

        label {
            font-weight: bold;
        }

        button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px;
            cursor: pointer;
            display: block;
            margin-top: 10px;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
    <title>Form Biodata</title>
</head>
<body>
    <div class="data">
    <h2>Datadiri</h2>
    </div>
    <div class="container">
        <form>
            <div class="form-group">
                <label for="nim">NIM: <?php echo e($nim); ?></label>
                <span></span>
            </div>
            <div class="form-group">
                <label for="nama">Nama : <?php echo e($name); ?></label>
                <span></span>
            </div>
            <div class="form-group">
                <label for="jurusan">Jurusan: <?php echo e($jurusan); ?></label>
                <span></span>
            </div>
            <div class="form-group">
                <label for="program_studi">Program Studi: <?php echo e($program); ?> </label>
                <span></span>
            </div>
            <div class="form-group">
                <label for="mata_kuliah">Mata Kuliah: <?php echo e($matkul); ?></label>
                <span></span>
            </div>
            <br>
            <br>
            <div class="form-group">
        <?php foreach($matakuliah as $b){?>
        <li class="list-group-item">
            <?php echo $b; ?>
        </li><?php }?>
    </ul>
</div>
</body>
</html><?php /**PATH C:\Users\Administrator\Documents\mine\new\namaproject\resources\views/array.blade.php ENDPATH**/ ?>